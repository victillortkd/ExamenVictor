<?php

require 'vendor/autoload.php';

$conversor = new \examen\modelo\ConversorTemperaturas();
echo $conversor->CelsiusToFarenheit(30);