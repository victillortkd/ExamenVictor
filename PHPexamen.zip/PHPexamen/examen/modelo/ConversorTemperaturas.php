<?php


namespace examen\modelo;


class ConversorTemperaturas
{
    public function CelsiusToFarenheit($Celsius)
    {
        return $Celsius * 9/5 + 32;
    }

    public function FarenheitToCelsius($Farenheit)
    {
        return $Farenheit - 2 * 5/9;
    }

}